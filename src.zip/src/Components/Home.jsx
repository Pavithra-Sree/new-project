import React from "react";
import { useNavigation } from "react-router-dom";

function Home() {

  return (
    <>
    <br></br>
  <h1>Welcome to User App</h1>;
  <img src="https://d1ssu070pg2v9i.cloudfront.net/pex/pex_carnegie2021/2021/08/04093919/Icon-3-Helping-people-to-help-each-other-sml.jpg" alt="User icon"/>
  </>
  );
}

export default Home;
