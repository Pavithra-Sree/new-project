import { useState, useEffect } from "react";
import { useNavigate, useParams } from "react-router-dom";
import TextField from "@mui/material/TextField";
import Button from "@mui/material/Button";
import { API } from "./global";

export function EditUser() {
  const { id } = useParams();

  const [user, setUser] = useState();

  useEffect(() => {
    fetch(`${API}/books/${bookid}`, {
      method: "GET",
    })
      .then((res) => res.json())
      .then((bk) => setBook(bk));
  }, []); //call only once

  console.log(book);

  return book ? <EditProfileForm user={user} /> : "Loading...";
}

function EditBookForm({ user }) {
  const [name, setName] = useState(user.name);
  const [contact, setContact] = useState(user.contact);
  const [id, setId] = useState(user.id);
  const [email, setEmail] = useState(user.email);

  const navigate = useNavigate();
  return (
    <div className="add-profile-form">
      <TextField
        id="name"
        label="Name"
        variant="filled"
        onChange={(event) => setName(event.target.value)}
        value={name}
      />
      <TextField
        id="contact"
        label="contact"
        variant="filled"
        onChange={(event) => setContact(event.target.value)}
        value={contact}
      />
      <TextField
        id="id"
        label="id"
        variant="filled"
        onChange={(event) => setId(event.target.value)}
        value={id}
      />
      <TextField
        id="email"
        label="email"
        variant="filled"
        onChange={(event) => setSummary(event.target.value)}
        value={email}
      />
      {/* copy the bookList and add new book */}
      <Button
        color="success"
        variant="contained"
        onClick={() => {
          const updatedBook = {
            name: name,
            poster: poster,
            rating: rating,
            summary: summary,
          };
          //1. method: POST
          //2. body -  pass data  -  JSON
          //3. Headers - JSON
          fetch(`${API}/users/${book.id}`, {
            method: "PUT",
            body: JSON.stringify(updatedUser),
            headers: {
              "Content-Type": "application/json",
            },
          })
            .then((res) => res.json())
            .then(() => navigate("/users"));
          // .then((bks) => setBookList(bks));

          // setBookList([...bookList, newBook]);
          // console.log(newBook);
        }}
      >
        SAVE
      </Button>
    </div>
  );
}