import { Provider, LikeButton } from "@lyket/react";
import {Counter} from "./counter";

<Provider apiKey="acc0dbccce8e557db5ebbe6d605aaa">
  <LikeButton
    namespace="testing-react"
    id="everybody-like-now"
  />
  
</Provider>