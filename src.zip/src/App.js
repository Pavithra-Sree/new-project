//import logo from './logo.svg';

import './App.css';
import * as React from 'react';
import ReactDOM from "react-dom/client";
import { BrowserRouter, Routes, Route, Navigate, useNavigate } from "react-router-dom";
import Layout from "./Layout";
import Home from "./Components/Home";
import UserList from './userList';
import AppBar from "@mui/material/AppBar";
import Toolbar from "@mui/material/Toolbar";
import { ThemeProvider, createTheme } from "@mui/material/styles";
import Button from "@mui/material/Button";
import Header from "./Header";


export default function App() {
//const navigate = useNavigate();
  return(
    
    <div className="App">
    {/* <AppBar position="static">
          <Toolbar>
            <Button onClick={() => navigate("/")} color="inherit">
              Home
            </Button>
            <Button onClick={() => navigate("/users")} color="inherit">
              Users
            </Button>
          </Toolbar>
    </AppBar> */}
    <BrowserRouter>
      <Routes>
     
         {/* <Route path="/" element={<Home />}>  */}
         <Route path="/" element={<Layout />}> 
         <Route path="home" element={<Home />} /> 
         <Route path="users" element={<UserList />} />
        </Route>
      </Routes>
    </BrowserRouter>  
    <Header/>
    </div>
  );
}

//export default App;
{/* <div className="App">

{userList.map((m) =>  {
return (
<>
<Card sx={{ maxWidth: 345 }}></Card>

  <h1>{m.name}</h1>
  <img src={m.avatar} alt={m.name}></img>
  <p>{m.contact}</p>
  <p>{m.email}</p>
  <p>{m.password}</p>
</>

)
}       
)}

</div> */}

// function App() {

//   const [userList, setUserList] = useState([]);
//   const [mode, setMode] = useState("light");
//   const getUsers = () => {

//     fetch("https://648bfc4a8620b8bae7ec01dc.mockapi.io/users", {

//     method: "GET",
//       })
// .then((data) => data.json())
// .then((user) => setUserList(user));
// };

// useEffect(() => getUsers(), []);
// //const navigate = useNavigate();
//   return (
//     <div className="App">
//           {userList.map((m) =>  {
// return (
// <div>
//   <Card sx={{ maxWidth: 400 }}>
//   <CardMedia
//           component="img"
//           height="300"
//           font-family = "algerian"
//           font-size= "10"
//           image={m.avatar}
//           alt={m.name}
          
//         />
//         <CardContent>
          
//           <Typography gutterBottom variant="h6" component="div">
//             <h1>{m.name}</h1>
//             <counter />
//             <hr></hr>
//           </Typography>
//             {/* <img src={m.avatar} alt={m.name}></img> */}
//             <Typography variant="body2" color="text.secondary">
//             <p><b>Contact:</b> {m.contact}</p>
//             <p><b>Employee_ID:</b> {m.id}</p>
//             <p><b>Email:</b> {m.email}</p>
//             <Provider apiKey="acc0dbccce8e557db5ebbe6d605aaa">
//   <LikeButton
//     namespace="testing-react"
//     id="everybody-like-now"
//   />
//   <counter />
// </Provider>
//             {/* <p><b>Password:</b> {m.password}</p> */}
            
//             </Typography>
//         </CardContent>
//   </Card>
//   </div>

// )
//           }       
//           )}

//     </div>
 
//   );

// }



// function App() {
//   //const navigate = useNavigate();
//   return(
//     <div className="App">
//       <AppBar> 
//        <Toolbar>
//         <Typography>HOME </Typography>
//        </Toolbar>
//         </AppBar>
//       <Home/>
//     </div>
//   );
// }
// const root= ReactDOM.createRoot(document.getElementById('root'));
// root.render(
// <React.StrictMode>
// <App/>
// </React.StrictMode>
// );
// reportWebVitals();

{/* <AppBar position="static">
          <Toolbar>
            <Button onClick={() => navigate("/")} color="inherit">
              Home
            </Button>
            <Button onClick={() => navigate("/users")} color="inherit">
              Users
            </Button>
          </Toolbar>
    </AppBar>    */}